//
//  MovieListTableViewCell.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 19/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class MovieListTableViewCell: UITableViewCell {

    @IBOutlet weak var viewCard: UIView?
    @IBOutlet weak var imageMovie: UIImageView?
    @IBOutlet weak var buttonPlay: UIButton?
    @IBOutlet weak var labelTitle: UILabel?
    @IBOutlet weak var labelReleaseDate: UILabel?
    @IBOutlet weak var labelOtherDetails: UILabel?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        buttonPlay?.backgroundColor = UIColor.systemBlue
        viewCard?.roundCorners(10.0)
        buttonPlay?.roundCorners(5.0)
        imageMovie?.roundCorners(5.0)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
