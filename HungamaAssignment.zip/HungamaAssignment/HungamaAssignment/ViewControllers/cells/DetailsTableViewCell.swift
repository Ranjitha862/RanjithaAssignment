//
//  DetailsTableViewCell.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 20/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class DetailsTableViewCell: UITableViewCell {

    @IBOutlet weak var imageMovie: UIImageView?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
