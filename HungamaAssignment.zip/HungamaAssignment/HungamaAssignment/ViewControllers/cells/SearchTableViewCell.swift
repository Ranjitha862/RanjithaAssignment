//
//  SearchTableViewCell.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 21/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class SearchTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
