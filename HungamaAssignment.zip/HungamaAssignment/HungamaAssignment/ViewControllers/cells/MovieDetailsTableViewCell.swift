//
//  MovieDetailsTableViewCell.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 23/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class MovieDetailsTableViewCell: UITableViewCell {

    @IBOutlet weak var labelOverview: UILabel?
    @IBOutlet weak var labelGenre: UILabel?
    @IBOutlet weak var labelLanguage: UILabel?
    @IBOutlet weak var labelReleaseDate: UILabel?
    @IBOutlet weak var labelTitle: UILabel?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
