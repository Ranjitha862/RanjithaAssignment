//
//  DetailsViewController.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 20/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView?
    
    var viewModel = DetailsViewModel()
    var genreArr = [Genre]()
    var detailsArr: Details?
    var searchArr: [Int]?
    var id: Int = 0
    
    var genreName1: String = ""
    var genreName2: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setData()
    }
    
    func setData(){
        
        self.navigationItem.title = "Movie Details"
        tblView?.delegate = self
        tblView?.dataSource = self
        self.tblView?.tableFooterView = UIView()
        tblView?.sectionHeaderHeight = 0.0
        tblView?.sectionFooterHeight = 0.0
        
        let vc = UINib(nibName: "DetailsTableViewCell", bundle: nil)
        tblView?.register(vc, forCellReuseIdentifier: "DetailsTableViewCell")
        
        let vc1 = UINib(nibName: "MovieDetailsTableViewCell", bundle: nil)
        tblView?.register(vc1, forCellReuseIdentifier: "MovieDetailsTableViewCell")
        
        viewModel.delegateDetails = self
        viewModel.getMovieDetails(id: id)
    }
    
}

extension DetailsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
        
    }
    
   
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0{
            return 200.0
        }else{
            return UITableView.automaticDimension
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellMain = UITableViewCell()
        if indexPath.section == 0{
      
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "DetailsTableViewCell") as? DetailsTableViewCell else{
            return UITableViewCell()
        }
        
        let url = "https://image.tmdb.org/t/p/w500"
            let urlString = url + (detailsArr?.backdropPath ?? "")
        let imageUrl = URL(string: urlString)
        let image = try? Data(contentsOf: imageUrl!)

        if let imageData = image {
            cell.imageMovie?.image = UIImage(data: imageData)
        }
        
        cellMain = cell
            
        }else{
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "MovieDetailsTableViewCell") as? MovieDetailsTableViewCell else{
                return UITableViewCell()
            }
            
            cell.labelTitle?.text = detailsArr?.originalTitle
            if let date = detailsArr?.releaseDate{
                cell.labelReleaseDate?.text = "Release Date - \(date)"
            }
            
            if let overview = detailsArr?.overview {
            cell.labelOverview?.text = "OverView - \(overview)"
            }
            
            if let tagline = detailsArr?.tagline {
                cell.labelGenre?.text = "Tagline - \(tagline)"
            }
            
            if let status = detailsArr?.status {
                cell.labelLanguage?.text = "Status - \(status)"
            }
           cellMain = cell
        }
        return cellMain
    }
}


extension DetailsViewController: DetailsViewModelProtocol {
    
    func fetchTaskFinished() {
        DispatchQueue.main.async {
            self.dismiss(animated: true, completion: nil)
            self.genreArr = self.viewModel.details?.genres ?? []
            self.detailsArr = self.viewModel.details
            
            self.tblView?.reloadData()
        }
    }
    
    func fetchTaskWithError() {
        
    }
}

extension DetailsViewController {
   
     func loader() {
        
        let alert = UIAlertController(title: nil, message: "", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.medium
        loadingIndicator.startAnimating();
        
        let height:NSLayoutConstraint = NSLayoutConstraint(item: alert.view, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
        
        let width:NSLayoutConstraint = NSLayoutConstraint(item: alert.view, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
        
        alert.view.addConstraint(height)
        alert.view.addConstraint(width)
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
}
