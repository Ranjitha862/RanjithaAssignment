//
//  ViewController.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 19/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView?
    
    var viewModel = ListViewModel()
    var resultArr = [Result]()
    var searchArr: [Int]?
    var id: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setData()
    }
    
    func setData(){
        
        self.navigationItem.title = "Movies"
        tblView?.delegate = self
        tblView?.dataSource = self
        self.tblView?.tableFooterView = UIView()
        tblView?.sectionHeaderHeight = 0.0
        tblView?.sectionFooterHeight = 0.0
        
        let vc = UINib(nibName: "MovieListTableViewCell", bundle: nil)
        tblView?.register(vc, forCellReuseIdentifier: "MovieListTableViewCell")

        let button1 : UIButton = UIButton.init(type: .custom)
        button1.setTitle("Search", for: .normal)
        button1.addTarget(self, action: #selector(searchTapped), for: .touchUpInside)
        button1.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        button1.setTitleColor(UIColor.blue, for: .normal)
        let addButton = UIBarButtonItem(customView: button1)
        
        navigationItem.setRightBarButtonItems([addButton], animated: true)
        
        viewModel.delegateList = self
        viewModel.getMovieList()
    }
    
    override func viewDidAppear(_ animated: Bool) {
       
       // NotificationCenter.default.addObserver(self, selector: #selector(loader), name: Notification.Name(rawValue: "loader"), object: nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
     //   NotificationCenter.default.removeObserver(self, name: Notification.Name(rawValue: "loader"), object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        
    }
    
    @objc func searchTapped(){
        
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as? SearchViewController {
            vc.searchArrayToDisplay = Singleton.sharedInstance.searchArray
            vc.resultArr = resultArr
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

//TableView delegate methods
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resultArr.count
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 190.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellMain = UITableViewCell()
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MovieListTableViewCell") as? MovieListTableViewCell else{
            return UITableViewCell()
        }
        
        let data = resultArr[indexPath.row]
        
        cell.labelTitle?.text = data.originalTitle
        if let releaseDate = data.releaseDate {
            cell.labelReleaseDate?.text = "Release Date - \(releaseDate)"
        }
        if let averageVote = data.voteAverage{
            cell.labelOtherDetails?.text = "Average vote - \(averageVote)"
        }
        
        let url = "https://image.tmdb.org/t/p/w500"
        let urlString = url + (data.posterPath ?? "")
        let imageUrl = URL(string: urlString)
        let image = try? Data(contentsOf: imageUrl!)
        
        if let imageData = image {
            cell.imageMovie?.image = UIImage(data: imageData)
        }
        
        cellMain = cell
        return cellMain
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let data = resultArr[indexPath.row]
        let id1 = data.id ?? 0
        self.id = id1
        Singleton.sharedInstance.searchArray.append(data.id ?? 0)
        
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as? DetailsViewController {
            vc.id = data.id ?? 0
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

//API Parsing
extension ViewController: ListViewModelProtocol {
    
    func fetchTaskFinished() {
        DispatchQueue.main.async {
            self.dismiss(animated: true, completion: nil)
            self.resultArr = self.viewModel.resultList?.results ?? []
            self.tblView?.reloadData()
        }
    }
    
    func fetchTaskWithError() {
        
    }
}

//loader to load
extension ViewController {
   
     func loader() {
        
        let alert = UIAlertController(title: nil, message: "", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.medium
        loadingIndicator.startAnimating();
        
        let height:NSLayoutConstraint = NSLayoutConstraint(item: alert.view, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
        
        let width:NSLayoutConstraint = NSLayoutConstraint(item: alert.view, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
        
        alert.view.addConstraint(height)
        alert.view.addConstraint(width)
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
}
