//
//  RESTfulServices.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 20/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import Foundation
import UIKit

class RESTfulServices: NSObject , URLSessionDelegate {

    static let shared = RESTfulServices()
    
    static func makeRESTCall(endpointURL: String, requestMethod: String, customCompletionHandler: @escaping ((_ data: Data?, _ response: URLResponse?, _ error : Error?)->Void)) {
        
        let url = URL(string: endpointURL.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
        
        var urlRequest = URLRequest (url: url!)
        urlRequest.httpMethod = requestMethod
        
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: shared, delegateQueue: OperationQueue.main)
        
        _ = session.dataTask(with:urlRequest, completionHandler: customCompletionHandler).resume()
    }
}
