//
//  SearchViewController.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 21/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController, UISearchBarDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar?
    @IBOutlet weak var tblView: UITableView?
    
    var searchArrayToDisplay: [Int] = []
    var resultArr = [Result]()
    var filteredData = [Result]()
    fileprivate var isSearching = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Search"
        searchBar?.delegate = self
    }
    
    func setData(){
        
        tblView?.delegate = self
        tblView?.dataSource = self
        self.tblView?.tableFooterView = UIView()
        tblView?.sectionHeaderHeight = 0.0
        tblView?.sectionFooterHeight = 0.0
        
        let vc = UINib(nibName: "SearchTableViewCell", bundle: nil)
        tblView?.register(vc, forCellReuseIdentifier: "SearchTableViewCell")
        
        isSearching = false
        searchBar?.text = ""
        searchBar?.delegate = self
    }
}

extension SearchViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearching{
            return filteredData.count//searchArrayToDisplay.count ?? 0
        }else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellMain = UITableViewCell()
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SearchTableViewCell") as? SearchTableViewCell else{
            return UITableViewCell()
        }
        if isSearching{
            let data = filteredData[indexPath.row]
            cell.titleLabel?.text = data.originalTitle
        }
        
        cellMain = cell
        return cellMain
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        setData()
    }
}

extension SearchViewController: UITextViewDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        let searchString = searchText.trimWhiteSpace()
        searchBar.showsCancelButton = true
        if searchText == "" {
            isSearching = false
            view.endEditing(true)
            tblView?.reloadData()
            
        } else {
            
            if searchString != "", searchString.count > 0 {
                let getFilterData = resultArr.filter {
                    return $0.originalTitle?.range(of: searchString, options: .caseInsensitive) != nil
                }
                isSearching = true
                filteredData = getFilterData
                self.tblView?.reloadData()
            }
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        searchBar.text = ""
        searchBar.showsCancelButton = true
        if searchBar.text == "" {
            view.endEditing(true)
            
            if searchBar.text == "" {
                isSearching = false
                view.endEditing(true)
                tblView?.reloadData()
            }
        }
    }
    
    
}

extension String {
    func trimWhiteSpace() -> String {
        let string = self.trimmingCharacters(in: .whitespacesAndNewlines)
        return string
    }
}

extension UISearchBar {
    
    func alwaysShowCancelButton() {
        for subview in self.subviews {
            for ss in subview.subviews {
                if #available(iOS 13.0, *) {
                    for s in ss.subviews {
                        self.enableCancel(with: s)
                    }
                }else {
                    self.enableCancel(with: ss)
                }
            }
        }
    }
    private func enableCancel(with view:UIView) {
        if NSStringFromClass(type(of: view)).contains("UINavigationButton") {
            (view as! UIButton).isEnabled = true
        }
    }
}


