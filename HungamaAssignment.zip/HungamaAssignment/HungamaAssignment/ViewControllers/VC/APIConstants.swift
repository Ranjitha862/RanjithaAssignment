//
//  APIConstants.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 20/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import Foundation

class APIConstants{
    
    static var baseServer: String = "https://api.themoviedb.org/3/movie/"
    
    class func movieList() -> String {
           return "\(baseServer)"
       }
}
