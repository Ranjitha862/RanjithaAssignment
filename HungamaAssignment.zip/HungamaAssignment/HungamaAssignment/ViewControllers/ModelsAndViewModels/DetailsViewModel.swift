//
//  DetailsViewModel.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 23/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import Foundation
import UIKit

protocol DetailsViewModelProtocol: AnyObject {
    
    func fetchTaskFinished()
    func fetchTaskWithError()
    
}

class DetailsViewModel: NSObject {
    
    weak var delegateDetails: DetailsViewModelProtocol?
    var details: Details?
    var movieId: Int = 0
    
    func getMovieDetails(id: Int){
        
        let apiKey = Singleton.sharedInstance.apiKey
        let urlString = APIConstants.movieList()
        let url = urlString + "\(id)?api_key=\(apiKey)"
        
        RESTfulServices.makeRESTCall(endpointURL: url, requestMethod: "GET", customCompletionHandler: getMovieList)
   
    }
    
    //API Handler
    func getMovieList(data: Data?, response: URLResponse?, error : Error?) -> Void  {
        
        if error != nil {
            DispatchQueue.main.async {
                self.delegateDetails?.fetchTaskWithError()
            }
        }
            
        else {
            do {
                
                if let httpResponse = response as? HTTPURLResponse {
                    if (httpResponse.statusCode == 401 || httpResponse.statusCode == 402) {
                        return
                    }
                }
                let decoder = JSONDecoder()
                
                let rep =  try decoder.decode(Details.self, from: data!)
                
                DispatchQueue.main.async {
                    self.details = rep
                    self.delegateDetails?.fetchTaskFinished()
                }
            }
                
            catch let errorLocal as NSError {
                print(errorLocal)
                self.delegateDetails?.fetchTaskWithError()
                
            }
        }
    }
}
