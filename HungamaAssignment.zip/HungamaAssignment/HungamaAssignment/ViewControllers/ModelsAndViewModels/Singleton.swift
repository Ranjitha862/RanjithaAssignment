//
//  Singleton.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 21/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import Foundation

class Singleton {
    
    static let sharedInstance = Singleton()
    private init() { }
    
    var apiKey: String = "735aa53e3d2aa602f0040fba9740cd30"
    var searchArray: [Int] = []
}
