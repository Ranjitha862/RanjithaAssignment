//
//  ListViewModel.swift
//  HungamaAssignment
//
//  Created by Ranjitha S on 20/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

//protocol to pursue API
protocol ListViewModelProtocol: AnyObject {
    
    func fetchTaskFinished()
    func fetchTaskWithError()
    
}

class ListViewModel: NSObject {
    
    weak var delegateList: ListViewModelProtocol?
    var resultList: Welcome?
    
    func getMovieList(){
        
        let apiKey = Singleton.sharedInstance.apiKey
        let urlString = APIConstants.movieList()
        let url = urlString + "now_playing?api_key=\(apiKey)"
        
        RESTfulServices.makeRESTCall(endpointURL: url, requestMethod: "GET", customCompletionHandler: getMovieList)
      //  NotificationCenter.default.post(name: Notification.Name(rawValue: "loader"), object: nil)
    }
    
    //API Handler
    func getMovieList(data: Data?, response: URLResponse?, error : Error?) -> Void  {
        
        if error != nil {
            DispatchQueue.main.async {
                self.delegateList?.fetchTaskWithError()
            }
        }
            
        else {
            do {
                
                if let httpResponse = response as? HTTPURLResponse {
                    if (httpResponse.statusCode == 401 || httpResponse.statusCode == 402) {
                        return
                    }
                }
                let decoder = JSONDecoder()
                
                let rep =  try decoder.decode(Welcome.self, from: data!)
                
                DispatchQueue.main.async {
                    self.resultList = rep
                    self.delegateList?.fetchTaskFinished()
                }
            }
                
            catch let errorLocal as NSError {
                print(errorLocal)
                self.delegateList?.fetchTaskWithError()
                
            }
        }
    } 
}
